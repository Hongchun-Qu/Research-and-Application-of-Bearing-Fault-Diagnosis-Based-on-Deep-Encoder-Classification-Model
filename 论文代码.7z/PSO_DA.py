import numpy as np
import random
import matplotlib.pyplot as plt
import math
import shujuchuli
from DHA_CDA import DHA_CDA
from DHA_SDA import DHA_SDA
from DHA_DDA import DHA_DDA


def fit_fun(X, data, data_label, encoder):  # 适应函数

    if encoder == 'sda_para':
        sda = DHA_SDA(X[0], X[1], X[2], lr=X[3], train_step=20)
        _, cost, accuracy = sda.fit(data, data_label)
    elif encoder == 'cda_para':
        cda = DHA_CDA(X[0], X[1], X[2], X[3], lr=X[4], train_step=20)
        _, cost, accuracy = cda.fit(data, data_label)
    elif encoder == 'dda_para':
        dda = DHA_DDA(X[0], X[1], X[2], lr=X[3], train_step=20)
        _, cost, accuracy = dda.fit(data, data_label)

    return cost, accuracy


class Particle:  # 粒子
    # 初始化
    def __init__(self, x_max, x_min, lr_max, lr_min, dim, data, data_label, encoder_para):

        self.__pos = [random.uniform(lr_min, lr_max) if i == dim - 1 else random.randint(x_min, x_max)
                      for i in range(dim)]  # 粒子的位置   随机生成一个实数
        # self.__vel = [random.uniform(-max_vel, max_vel) for i in range(dim)]  # 粒子的速度
        self.__vel = [random.uniform(lr_min, lr_max) if i == dim - 1 else random.uniform(x_min, x_max)
                      for i in range(dim)]
        self.__bestPos = [0.0 for i in range(dim)]  # 粒子最好的位置
        self.__fitnessValue_cost, self.__fitnessValue_acc = fit_fun(self.__pos, data, data_label, encoder_para)  # 适应度函数值

    def set_pos(self, i, value):
        self.__pos[i] = value

    def get_pos(self):
        return self.__pos

    def set_best_pos(self, i, value):
        self.__bestPos[i] = value

    def get_best_pos(self):
        return self.__bestPos

    def set_vel(self, i, value):
        self.__vel[i] = value

    def get_vel(self):
        return self.__vel

    def set_fitness_value(self, value1, value2):
        self.__fitnessValue_cost = value1
        self.__fitnessValue_acc = value2

    def get_cost_value(self):
        return self.__fitnessValue_cost

    def get_accuracy_value(self):
        return self.__fitnessValue_acc

class PSO:
    def __init__(self, size, iter_num, data, data_label, sda_para=False, cda_para=False, dda_para=False,
                 best_fitness_cost=float('Inf'), best_fitness_accuracy=float('Inf'), C1=2, C2=2, W=1, dim=4):

        self.C1 = C1   # 局部学习因子，表示粒子移动到该粒子历史最优位置(pbest)的加速项的权重
        self.C2 = C2   # 全局学习因子，表示粒子移动到所有粒子最优位置(gbest)的加速项的权重
        self.W = W     # 惯性因子，表示粒子之前运动方向在本次方向上的惯性
        self.dim = dim  # 粒子的维度
        self.size = size  # 粒子个数
        self.iter_num = iter_num  # 迭代次数
        self.data = data
        self.data_label = data_label
        self.unit_max = 500
        self.unit_min = 50
        self.max_unit_vel = 200
        self.max_lr_vel = 0.005
        self.lr_max = 0.02
        self.lr_min = 0.004
        self.best_fitness_cost = best_fitness_cost
        self.best_fitness_accuracy = best_fitness_accuracy
        self.best_position = [0.0 for i in range(dim)]  # 种群最优位置
        self.fitness_cost_list = []  # 每次迭代最优适应值
        self.fitness_accuracy_list = []  # 每次迭代最优适应值

        if sda_para == True:
            self.encoder_para = 'sda_para'
        elif cda_para == True:
            self.encoder_para = 'cda_para'
        elif dda_para == True:
            self.encoder_para = 'dda_para'


        # if sda_para == True:
        #     self.encoder_para = 'sda_para'
        #     self.lr_max = 0.015
        #     self.lr_min = 0.006
        # elif cda_para == True:
        #     self.encoder_para = 'cda_para'
        #     self.lr_max = 0.04
        #     self.lr_min = 0.007
        # elif dda_para == True:
        #     self.encoder_para = 'dda_para'
        #     self.lr_max = 0.03
        #     self.lr_min = 0.007

        # 对种群进行初始化
        self.Particle_list = [Particle(self.unit_max, self.unit_min, self.lr_max, self.lr_min,
                                    self.dim, self.data, self.data_label, self.encoder_para)
                              for i in range(self.size)]

    def set_bestFitnessValue(self, value1, value2):
        self.best_fitness_cost = value1
        self.best_fitness_accuracy = value2

    def get_bestAccuracyValue(self):
        return self.best_fitness_accuracy

    def get_bestCostValue(self):
        return self.best_fitness_cost

    def set_bestPosition(self, i, value):
        self.best_position[i] = value

    def get_bestPosition(self):
        return self.best_position

    # 更新速度
    def update_vel(self, part):
        for i in range(self.dim):
            vel_value = self.W * part.get_vel()[i] + self.C1 * random.random() * (part.get_best_pos()[i] - part.get_pos()[i]) \
                        + self.C2 * random.random() * (self.get_bestPosition()[i] - part.get_pos()[i])
            if 0<=i<3:
                if vel_value > self.max_unit_vel:
                    vel_value = self.max_unit_vel
                elif vel_value < -self.max_unit_vel:
                    vel_value = -self.max_unit_vel
            else:
                if vel_value > self.max_lr_vel:
                    vel_value = self.max_lr_vel
                elif vel_value < -self.max_lr_vel:
                    vel_value = -self.max_lr_vel
                    # 速度限制的作用为：维护算法的探索能力与开发能力的平衡V​
                    # Vm较大时，探索能力强，但是粒子容易飞过最优解
                    # Vm较小时，开发能力强，但是容易陷入局部最优解
                    # Vm一般设定为每维变量变化范围的10%~20%
            part.set_vel(i, vel_value)

    # 更新位置
    def update_pos(self, part):
        for i in range(self.dim):
            pos_value = part.get_pos()[i] + part.get_vel()[i]
            if 0 <= i < self.dim-1:
                if isinstance(pos_value, float):
                    p = math.modf(pos_value)  # 分别取出整数部分和小数部分  输出tuple（1，2）2为整数部分，1为小数部分
                    p_1 = int(p[1])  # 把整数部分转换为int
                    if p[0] >= 0.5:
                        pos_value = p_1 + 1
                    else:
                        pos_value = p_1
                if pos_value < 0:
                    pos_value = self.unit_min
            else:
                if pos_value <=0:
                    pos_value = self.lr_min
            part.set_pos(i, pos_value)
        cost, acc = fit_fun(part.get_pos(),self.data, self.data_label, self.encoder_para)
        if cost < part.get_cost_value():
            part.set_fitness_value(cost, acc)
            for i in range(self.dim):
                part.set_best_pos(i, part.get_pos()[i])
        if cost < self.get_bestCostValue():
            self.set_bestFitnessValue(cost, acc)
            for i in range(self.dim):
                self.set_bestPosition(i, part.get_pos()[i])

    def update(self):
        num = self.iter_num
        for i in range(self.iter_num):
            # 优化
            for part in self.Particle_list:
                self.update_vel(part)  # 更新速度
                self.update_pos(part)  # 更新位置
            costvalue = self.get_bestCostValue()
            accuracyvalue = self.get_bestAccuracyValue()
            self.fitness_cost_list.append(costvalue)  # 每次迭代完把当前的最优适应度存到列表
            self.fitness_accuracy_list.append(accuracyvalue)

        # self.plot(self.fitness_cost_list, num)
        # self.plot(self.fitness_accuracy_list, num)
        print("PSO最优位置:" + str(self.get_bestPosition()))
        print("PSO cost最优解:" + str(self.fitness_cost_list))
        print("PSO accuracy最优解:" + str(self.fitness_accuracy_list))

        return self.get_bestPosition()

    def plot(self, results, num):
        '''画图
        '''
        X = []
        Y = []
        for i in range(num):
            X.append(i + 1)
            Y.append(results[i])
        plt.plot(X, Y)
        plt.xlabel('Number of iteration', size=10)
        plt.ylabel('Value of cost', size=10)
        plt.title('encoder parameter optimization')
        plt.show()


if __name__ == '__main__':
    data = shujuchuli.cut_samples(0)
    train_x, train_y, test_x, test_y, val_x, val_y = shujuchuli.make_datasets(data)
    train_x = train_x[:100,:]
    train_y = train_y[:100, :]
    val_x = val_x[:50,:]
    val_y = val_y[:50,:]

    train_y = np.argmax(train_y, 1).astype(np.int64)
    species = set(train_y)  # 数据可以分为几类  # unhashable type: 'numpy.ndarray'
    train_y = train_y.reshape(-1, 1)
    val_y = np.argmax(val_y, 1).astype(np.int64).reshape(-1, 1)
    test_y = np.argmax(test_y, 1).astype(np.int64).reshape(-1, 1)

    size = 2
    iter_num = 3

    pso = PSO(size, iter_num, train_x, train_y, sda_para=True)
    best_pos = pso.update()
    print("PSO最优位置:" + str(best_pos))


    # cda = Cda_suiji(best_pos[0], best_pos[1], best_pos[2], lr=best_pos[3])
    # _, cost, accuracy = cda.fit(train_x, train_y, tree_i=0)
    # acc, _ = cda.test(test_x, test_y, tree_i=0)

