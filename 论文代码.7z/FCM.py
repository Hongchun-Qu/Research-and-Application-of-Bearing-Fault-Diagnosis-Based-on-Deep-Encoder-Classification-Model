
'''
FCM代码来自：
https://blog.csdn.net/a19990412/article/details/89361038
'''


import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA


class FCM_encoder():

    def __init__(self):
        self.c_clusters = 10
        self.m = 2
        self.eps = 10

    def FCM(self, X):  # m : 模糊聚类参数
        # membership_mat:矩阵,每个点属于不同的集群的概率（隶属度）
        # 随机生成
        membership_mat = np.random.random((len(X), self.c_clusters))
        membership_mat = np.divide(membership_mat, np.sum(membership_mat, axis=1)[:, np.newaxis])  # 数组对应位置元素做除法
        # np.newaxis的功能:插入新维度
        while True:
            working_membership_mat = membership_mat ** self.m
            Centroids = np.divide(np.dot(working_membership_mat.T, X),
                                  np.sum(working_membership_mat.T, axis=1)[:, np.newaxis])

            # 求数据x和每个中心的距离，2指的是二范数
            n_c_distance_mat = np.zeros((len(X), self.c_clusters))
            for i, x in enumerate(X):
                for j, c in enumerate(Centroids):
                    n_c_distance_mat[i][j] = np.linalg.norm(x - c, 2)

            new_membership_mat = np.zeros((len(X), self.c_clusters))

            for i, x in enumerate(X):
                for j, c in enumerate(Centroids):
                    new_membership_mat[i][j] = 1. / np.sum(
                        (n_c_distance_mat[i][j] / n_c_distance_mat[i]) ** (2 / (self.m - 1)))

            # 迭代终点一般选取两个：当u变化的无穷范数小于某个值时、或者当迭代次数达到某个极限时候
            if np.sum(abs(new_membership_mat - membership_mat)) < self.eps:  # 终止条件
                break
            membership_mat = new_membership_mat
        return np.argmax(new_membership_mat, axis=1)  # 返回预测标签

    def evaluate(self, y, t):  # y是实际标签，t是预测标签
        a, b, c, d = [0 for i in range(4)]
        for i in range(len(y)):  # len(y)： 数据点的个数
            for j in range(i+1, len(y)):
                if y[i] == y[j] and t[i] == t[j]:
                    a += 1    # 数据 i 和 数据 j 实际是一类，预测也是一类 ： TP
                elif y[i] == y[j] and t[i] != t[j]:
                    b += 1    # 数据 i 和 数据 j 实际是一类，预测不是一类：FN
                elif y[i] != y[j] and t[i] == t[j]:
                    c += 1    # 数据 i 和 数据 j 实际不是一类，预测是一类 ：FP
                elif y[i] != y[j] and t[i] != t[j]:
                    d += 1    # 数据 i 和 数据 j 实际不是一类，预测也不是一类 ：TN
        return a, b, c, d

    def external_index(self, a, b, c, d, m):
        JC = a / (a + b + c)
        FMI = np.sqrt(a**2 / ((a + b) * (a + c)))
        RI = 2 * ( a + d ) / ( m * (m + 1) )
        return JC, FMI, RI

    def evaluate_it(self, y, t):
        a, b, c, d = self.evaluate(y, t)
        return self.external_index(a, b, c, d, len(y))



# import shujuchuli
# from CDA_1 import Cda_suiji
#
# data = shujuchuli.cut_samples(-15)
# train_x, train_y, test_x, test_y, val_x, val_y = shujuchuli.make_datasets(data)
# model = Cda_suiji(100, 50, 20, 10, 0.008)
# encoder_output = model.fit(train_x, train_y, 0)
#
# fcm = FCM_encoder()
# pre_y = fcm.FCM(encoder_output)
#
#
# fcm.evaluate_it(np.argmax(train_y, 1), pre_y)
# X_reduced = PCA(n_components=2).fit_transform(encoder_output)
# plt.scatter(X_reduced[:, 0], X_reduced[:, 1], c=pre_y, cmap=plt.cm.Set1)
# plt.show()
# plt.scatter(X_reduced[:, 0], X_reduced[:, 1], c=np.argmax(train_y, 1), cmap=plt.cm.Set1)
# plt.show()
#
#
#
# import time
# from DynamicHypersphereAlgorithm import DHA
#
# DHA_classifier = DHA(encoder_output, pre_y, test_x, test_y, train_step=40, batch_size=20, lr=0.001)
# t1 = time.time()
# DHA_classifier.gen_model()
# t2 = time.time()
# print('图生成及训练时间：%.2f s'%(t2 - t1))
# DHA_classifier.plot_R()
# DHA_classifier.plot_loss()
# DHA_classifier.plot_pre_point_2D()
# DHA_classifier.plot_aff_point_2D()
# plt.show()
