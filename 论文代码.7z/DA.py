import tensorflow as tf
import numpy as np
import os
import shujuchuli
import matplotlib.pyplot as plt
import keras.backend as K
from FCM import FCM_encoder

from evaluation_and_figure import Evaluation_figure

# lrp逐层相关性传播 https://git.tu-berlin.de/gmontavon/lrp-tutorial
# lrp  http://heatmapping.org
# lrp https://github.com/sebastian-lapuschkin/lrp_toolbox
# 贝叶斯规则列表 https://github.com/corels/pycorels/tree/3a05b4a5df2b400df3e02b09cf16cb6424d9f33b
'''
在小高斯噪声的限制下，当重构函数将 x 映射到输出时，去噪重构误差与收缩惩罚项是等价的。
换句话说， 去噪自编码器能抵抗小且有限的输入扰动，而收缩自编码器使特征提取函数能抵抗极小的输入扰动。
去噪AE是针对输入，收缩AE是针对输出
'''

logdir = './CDA_model_save/logs/'
class Cda():   # 在python中 首字母大写指的是类

    def __init__(self, unit1, unit2, unit3, model_name):

        self.delta1 = 1e-3  # 雅克比惩罚项系数
        self.epoch = 1000
        self.keep_prop = 0.9  # 数据保留的比例， 用来防止过拟合
        self.unit1 = unit1
        self.unit2 = unit2
        self.unit3 = unit3
        self.pop = np.array([1200, self.unit1, self.unit2, self.unit3, 1])
        self.model_name = model_name
        self.rulelist_path = './' + self.model_name + '/rulelist/'
        self.fault_name = ['Ball14', 'Ball21', 'Ball7', 'IR14', 'IR21',
                           'IR7', 'Normal', 'OR14', 'OR21', 'OR7']
        self.graph_encoder = tf.Graph()
        with self.graph_encoder.as_default():
            self.x = tf.placeholder(tf.float64, [None, 1200], name='x')  # 输入数据
            self.x_label = tf.placeholder(tf.float64, [None, 10], name='x_label')  # 标签

    def loss_math(self, data, outputdata, hidden_w, hidden):

        error_loss = tf.reduce_mean(tf.square(outputdata - data))
        #雅克比矩阵 https://wiseodd.github.io/techblog/2016/12/05/contractive-autoencoder/
        J_w = K.transpose(hidden_w)
        d_sigmoid = hidden * (1 - hidden)
        contractive = self.delta1 * K.sum(d_sigmoid ** 2 * K.sum(J_w ** 2, axis=1), axis=1)

        loss_ae = error_loss + contractive
        optimizer_ae = tf.train.AdamOptimizer(learning_rate=0.01).minimize(loss_ae, var_list=tf.trainable_variables())

        return loss_ae, optimizer_ae


    def fit(self, train_x, train_y, tree_i):

        with tf.name_scope(self.model_name, values=[self.x]):
            self.activations = []

            with tf.name_scope('hidden_layer1'):
                hidden_w1 = tf.cast(tf.Variable(initial_value=tf.random_normal(shape=[self.pop[0], self.pop[1]]),
                                                name='hidden_w1'), tf.float64)  # float32
                hidden_b1 = tf.cast(tf.Variable(initial_value=tf.random_normal(shape=[self.pop[4], self.pop[1]]),
                                                name='hidden_b1'), tf.float64)
                hidden1 = tf.nn.sigmoid(tf.add(tf.matmul(self.x, hidden_w1), hidden_b1))
                output_w1 = tf.cast(tf.Variable(initial_value=tf.random_normal(shape=[self.pop[1], self.pop[0]]),
                                                name='output_w_1'), tf.float64)
                output_b1 = tf.cast(tf.Variable(initial_value=tf.random_normal(shape=[self.pop[4], self.pop[0]]),
                                                name='output_b_1'), tf.float64)
                output_ae1 = tf.nn.sigmoid(tf.add(tf.matmul(hidden1, output_w1), output_b1))
                self.activations += [hidden1]

            with tf.name_scope('hidden_layer2'):
                hidden_w2 = tf.cast(tf.Variable(initial_value=tf.random_normal(shape=[self.pop[1], self.pop[2]]),
                                                name='hidden_w2'), tf.float64)  # float32
                hidden_b2 = tf.cast(tf.Variable(initial_value=tf.random_normal(shape=[self.pop[4], self.pop[2]]),
                                                name='hidden_b2'), tf.float64)
                hidden2 = tf.nn.sigmoid(tf.add(tf.matmul(hidden1, hidden_w2), hidden_b2))
                output_w2 = tf.cast(tf.Variable(initial_value=tf.random_normal(shape=[self.pop[2], self.pop[1]]),
                                                name='output_w_2'), tf.float64)
                output_b2 = tf.cast(tf.Variable(initial_value=tf.random_normal(shape=[self.pop[4], self.pop[1]]),
                                                name='output_b_2'), tf.float64)
                output_ae2 = tf.nn.sigmoid(tf.add(tf.matmul(hidden2,output_w2), output_b2))
                self.activations += [hidden2]

            with tf.name_scope('hidden_layer3'):
                hidden_w3 = tf.cast(tf.Variable(initial_value=tf.random_normal(shape=[self.pop[2], self.pop[3]]),
                                                name='hidden_w3'), tf.float64)  # float32
                hidden_b3 = tf.cast(tf.Variable(initial_value=tf.random_normal(shape=[self.pop[4], self.pop[3]]),
                                                name='hidden_b3'), tf.float64)
                self.hidden3 = tf.nn.sigmoid(tf.add(tf.matmul(hidden2, hidden_w3), hidden_b3), name='encoder_output')

                out_w3 = tf.cast(tf.Variable(initial_value=tf.random_normal(shape=[self.pop[3], self.pop[2]]),
                                             name='out_w_3'), tf.float64)
                out_b3 = tf.cast(tf.Variable(initial_value=tf.random_normal(shape=[self.pop[4], self.pop[2]]),
                                             name='out_b_3'), tf.float64)
                out_ae3 = tf.nn.sigmoid(tf.add(tf.matmul(self.hidden3, out_w3), out_b3))
                self.activations += [self.hidden3]

          # 逐层训练
            self.loss_cae1, self.optimizer_cae1 = self.loss_math(self.x, output_ae1, hidden_w1, hidden1)
            self.loss_cae2, self.optimizer_cae2 = self.loss_math(hidden1, output_ae2, hidden_w2, hidden2)
            self.loss_cae3, self.optimizer_cae3 = self.loss_math(hidden2, out_ae3, hidden_w3, self.hidden3)

            tf.add_to_collection('LRP', self.x)
            for act in self.activations:
                tf.add_to_collection('LRP', act)
            self.summary = tf.summary.merge_all()

            # saver = tf.train.Saver()
            #
            # with tf.Session(graph=self.graph_encoder) as sess:
            #     sess.run(tf.global_variables_initializer())
            #
            #     self.file_writer = tf.summary.FileWriter(logdir, tf.get_default_graph())   # 生成logs文件
            #     for i in range(100):
            #         loss_1, loss_2, loss_3 = sess.run([self.loss_cae1, self.loss_cae2, self.loss_cae3],
            #                              feed_dict={self.x: train_x, self.x_label: train_y})
            #
            #     encoder_output = sess.run(self.hidden3, feed_dict={self.x: train_x, self.x_label: train_y})
            #     saver.save(sess, './' + self.model_name +'/model-' + str(tree_i))

            return self.hidden3


    def test(self, data_x, data_y, tree_i):

        graph_da1 = tf.Graph()
        sess_da1 = tf.Session(graph=graph_da1)
        with graph_da1.as_default():
            with sess_da1.as_default():
                sess_da1.run(tf.global_variables_initializer())
                saver = tf.train.import_meta_graph('./' + self.model_name +'/model-' + str(tree_i) + '.meta')
                saver.restore(sess_da1, './' + self.model_name +'/model-' + str(tree_i))
                graph_cda1 = tf.get_default_graph()
                x = graph_cda1.get_tensor_by_name('x:0')
                x_label = graph_cda1.get_tensor_by_name('x_label:0')

                if tree_i < 0:
                    encoder_output = graph_cda1.get_tensor_by_name(
                        self.model_name + '_' + str(abs(tree_i)) + '/hidden_layer3/encoder_output:0')
                else:
                    encoder_output = graph_cda1.get_tensor_by_name(
                        self.model_name + '/hidden_layer3/encoder_output:0')

                encoder_output = sess_da1.run(encoder_output, feed_dict={x: data_x, x_label: data_y})
                sess_da1.close()

            return encoder_output


if __name__ == "__main__":
    data = shujuchuli.cut_samples(0)
    train_x, train_y, test_x, test_y, val_x, val_y = shujuchuli.make_datasets(data)

    model_name = 'cda_name_scope'
    model = Cda(900, 600, 300, model_name)
    encoder_output = model.fit(train_x, train_y, 0)
    test_data = model.test(val_x, val_y, 0)



    # train_x = train_x[:100, :]
    # train_y = train_y[:100, :]
    # val_x = val_x[:50, :]
    # val_y = val_y[:50, :]

    # from pso_encoder import PSO
    # pso_size = 5
    # pso_iter_num = 20
    # pso_cda = PSO(pso_size, pso_iter_num, train_x, train_y, cda_para=True, dim=5)
    # best_pos_cda = pso_cda.update()
    # print("CDA最优位置:" + str(best_pos_cda))
    #
    # model = Cda_suiji(best_pos_cda[0], best_pos_cda[1], best_pos_cda[2], best_pos_cda[3], lr=best_pos_cda[4])

    # _, _, _ = model.fit(train_x, train_y, 0)
    # _ = model.test(val_x, val_y, 0)
    # model = Cda_suiji()
    # model.fit(train_x, train_y, -1)
    # _, _ = model.test(val_x, val_y, -1)
    # model = Cda_suiji()
    # model.fit(train_x, train_y, -2)
    # _, _ = model.test(val_x, val_y, -2)
    # model = Cda_suiji()
    # model.fit(train_x, train_y, -3)
    # _, _ = model.test(val_x, val_y, -3)




